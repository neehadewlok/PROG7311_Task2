﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PROG7311_Task2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PROG7311_Task2.Controllers
{
    public class LoginController : Controller
    {
        PROG7311TASK2Context db = new PROG7311TASK2Context();
        public LoginController(PROG7311TASK2Context context)
        {
            db = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login (string username, string password)
        {
            User u = db.Users.Where(us => us.Username.Equals(username) && us.Password.Equals
            (password)).FirstOrDefault();
            if (u != null)
            {
                //allow to see contacts
               //HttpContext.Session.SetString("LoggedInUser", u.Username);
               //TempData["UsernameAsTempData"] = u.Username;
               return RedirectToAction("Index", "Users");
            }
            else
            {
                //user needs to try again
                ViewBag.Error = "Incorrect details have been entered. Please try again.";
                return View();
            }
        }
        [HttpGet]
        public IActionResult Logout()
        {
            return View();
        }
    }
}
